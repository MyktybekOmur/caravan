import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caravan',
  templateUrl: './caravan.component.html',
  styleUrls: ['./caravan.component.scss'],
})
export class CaravanComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
